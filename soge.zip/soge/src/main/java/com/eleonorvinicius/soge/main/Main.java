package com.eleonorvinicius.soge.main;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Main {

	private static final String FILES_DIRECTORY = "D:\\opt\\workspace\\soge\\files\\";

	public static void main(String[] args) {
		File directory = new File(FILES_DIRECTORY);
		String[] list = directory.list();
		for (String file : list) {
			System.out.println("###");
			System.out.println("###" + file);
			System.out.println("###");
			try {
				FileInputStream fileInputStream = new FileInputStream(new File(FILES_DIRECTORY+file));
				Workbook workbook = WorkbookFactory.create(fileInputStream);
				Sheet sheet = workbook.getSheetAt(0);
				Row row = sheet.getRow(1);
				Iterator<Cell> cellIterator = row.cellIterator();
				Integer ufColumn = null;
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					String s = null;
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_NUMERIC:
						s = String.valueOf(cell.getNumericCellValue());
						break;
					case Cell.CELL_TYPE_STRING:
						s = cell.getStringCellValue();
						break;
					}
					if (s.equals("UF")){
						ufColumn = cell.getColumnIndex(); 
					}
				}
				if (ufColumn == null){
					break;
				}
				
				Iterator<Row> rowIterator = sheet.iterator();
				int rowCount = 0;
				while (rowIterator.hasNext()) {
					row = rowIterator.next();
					if (rowCount < 2){
						rowCount += 1;
						continue;
					}
					cellIterator = row.cellIterator();
					int columnCount = 0;
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						columnCount += 1;
						switch (cell.getCellType()) {
						case Cell.CELL_TYPE_NUMERIC:
							System.out.print(cell.getNumericCellValue() + "|\t");
							break;
						case Cell.CELL_TYPE_STRING:
							System.out.print(cell.getStringCellValue() + "|\t");
							break;
						}
						if (columnCount == ufColumn){
							
						}
					}
				}
				fileInputStream.close();
				workbook.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}